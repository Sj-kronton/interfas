[IMPORTANTE]

Se debe seleccionar la opción de "Build with dependencies" antes de ejecutarlo; se encuentran en pom.xml.
